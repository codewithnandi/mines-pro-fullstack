Mines Pro fullstack. Run backend with: pip install -r backend/requirements.txt && python backend/app.py
Set API_BASE in frontend files if hosting frontend separately.
